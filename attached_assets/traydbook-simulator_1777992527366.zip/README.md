# TraydBook Owner Simulator

Universal simulation engine for testing user journeys across multiple apps.

## Installation

```bash
npm install
npx playwright install chromium
```

## Usage

### Test Contractor Flow
```bash
npm run test:contractor
```

### Test Owner Flow
```bash
npm run test:owner
```

### Test All User Types
```bash
npm run test:all
```

### Watch Browser (headed mode)
```bash
npm run test:headed
```

### Custom User Type
```bash
node run.js traydbook investor
```

## Adding New Apps

Edit `config.js`:

```javascript
export const APPS = {
  traydbook: { ... },
  yourapp: {
    url: 'https://yourapp.com',
    type: 'saas',
    users: {
      admin: { role: 'admin', flow: 'signup → dashboard → settings' },
      user: { role: 'user', flow: 'signup → onboarding → useFeature' }
    }
  }
};
```

Then add the corresponding methods to `engine.js`.

## CI/CD Integration

### GitHub Actions
```yaml
- name: Run Simulation
  run: |
    npm install
    npx playwright install chromium
    npm run test:all
```

### Coolify Scheduled Task
```bash
0 2 * * * cd /path/to/simulator && node run.js traydbook contractor
```

## Output

```
🎭 TraydBook Owner Simulator
   App: https://dev.traydbook.com
   User: contractor (contractor)
   Flow: signup → profile → findJobs → bid
──────────────────────────────────────────────────
  ✅ signup          Account created: sim_contractor_123@test.com (2341ms)
  ✅ profile         Profile completed (1567ms)
  ✅ findJobs        12 jobs found (892ms)
  ✅ bid             Bid submitted: $15,000 (1234ms)
══════════════════════════════════════════════════
  📊 SIMULATION RESULTS
  ──────────────────────────────────────────────────
  ✅ signup          Account created (2341ms)
  ✅ profile         Profile completed (1567ms)
  ✅ findJobs        12 jobs found (892ms)
  ✅ bid             Bid submitted: $15,000 (1234ms)
  ──────────────────────────────────────────────────
  ✅ Passed: 4/4
  ❌ Failed: 0/4
  ⏱️  Total Time: 6034ms
══════════════════════════════════════════════════
```
